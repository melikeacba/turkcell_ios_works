//
//  product.swift
//  6-Days
//
//  Created by Melike Açba on 14.01.2021.
//

import Foundation
import UIKit

struct Product{
    
    var title = ""
    var detail = ""
    var image = UIImage()
    var price = 0
    
    
}
