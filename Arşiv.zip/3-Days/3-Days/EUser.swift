//
//  EUser.swift
//  3-Days
//
//  Created by Melike Açba on 7.01.2021.
//

import Foundation

enum EUser {
    case name
    case surname
    case age
    case mail
    case city
    
}
