//
//  Meyveler.swift
//  Homework_3S
//
//  Created by Melike Açba on 24.01.2021.
//

import Foundation
import UIKit

struct Meyveler {
    var title = ""
    var detail = ""
    var price = " "
    var resim = UIImage()
}

